// Seleciona elementos
const editarBtn = document.getElementById('editarBtn');
const inputFoto = document.getElementById('inputFoto');
const fotoPerfil = document.getElementById('fotoPerfil');
const imgFoto = document.getElementById('img-foto');

// Quando clicar no botão, abre o seletor de arquivos
editarBtn.addEventListener('click', () => {
  inputFoto.click();
});

// Quando escolher uma nova foto
inputFoto.addEventListener('change', (event) => {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      fotoPerfil.style.backgroundImage = `url('${e.target.result}')`;
      if (imgFoto) {
        imgFoto.src = e.target.result;
      }
    };
    reader.readAsDataURL(file);
  }
});