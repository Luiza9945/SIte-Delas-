// =======================
// PEGANDO ELEMENTOS DO HTML
// =======================
const form = document.getElementById('loginForm');
const errorMsg = document.getElementById('errorMsg');


// =======================
// FUNÇÃO DE VALIDAÇÃO DOS CAMPOS
// =======================
function validarCampos() {
  const nome = document.getElementById('nome').value.trim();
  const email = document.getElementById('Gmail').value.trim();
  const senha = document.getElementById('Senha').value.trim();
  const confirmarSenha = document.getElementById('ConfirmarSenha').value.trim();

  // Verifica se os campos estão preenchidos
  if (!nome || !email || !senha || !confirmarSenha) {
    errorMsg.textContent = "Preencha todos os campos!";
    return false;
  }

  // Verifica se as senhas coincidem
  if (senha !== confirmarSenha) {
    errorMsg.textContent = "As senhas não coincidem!";
    return false;
  }

  // Se tudo estiver ok
  errorMsg.textContent = "";
  return true;
}


// =======================
// EVENTO DE ENVIO DO FORMULÁRIO
// =======================
form.addEventListener('submit', function(event) {
  event.preventDefault(); // Impede envio automático do formulário

  if (validarCampos()) {
    window.location.href = "usuária_perfil.html"; // Redireciona se estiver tudo certo
  }
});


// =======================
// FUNÇÃO PARA LINKS (Ex: "Não possui conta?")
// =======================
function irPara(pagina) {
  if (validarCampos()) {
    window.location.href = "usuária_perfil.html";
  }
}

function transicaoCadastro() {
  document.body.style.transition = "opacity 0.7s";
  document.body.style.opacity = "0";
  setTimeout(function() {
    window.location.href = "Cadastro.html";
  }, 700);
}

// =======================
// FUNÇÃO PARA TROCAR ENTRE TELAS (LOGIN/CADASTRO)
// =======================
function toggleForm() {
  const container = document.getElementById('container');
  container.classList.toggle("right-panel-active");
}
