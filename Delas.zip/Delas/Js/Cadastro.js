// =======================
// PEGANDO ELEMENTOS DO HTML
// =======================
const form = document.getElementById('form');
const errorMsg = document.getElementById('errorMsg');

// =======================
// FUNÇÃO DE VALIDAÇÃO DOS CAMPOS
// =======================
function validarCampos() {
  const nome = document.getElementById('nome').value.trim();
  const email = document.getElementById('Gmail').value.trim();
  const telefone = document.getElementById('Telefone').value.trim();
  const senha = document.getElementById('Senha').value.trim();
  const confirmarSenha = document.getElementById('ConfirmarSenha').value.trim();

  if (!nome || !email || !telefone || !senha || !confirmarSenha) {
    errorMsg.textContent = "Preencha todos os campos!";
    return false;
  }
  if (senha !== confirmarSenha) {
    errorMsg.textContent = "As senhas não coincidem!";
    return false;
  }
  errorMsg.textContent = "";
  return true;
}

// =======================
// EVENTO DE ENVIO DO FORMULÁRIO
// =======================
form.addEventListener('submit', function(event) {
  event.preventDefault();
  if (validarCampos()) {
    window.location.href = "usuária_perfil.html";
  }
});

// =======================
// FUNÇÃO PARA LINKS (Ex: "Já possui conta? Faça login")
// =======================
function irPara(pagina) {
  document.body.classList.add("hidden"); // Faz sumir com fade
  setTimeout(() => {
    window.location.href = pagina; // Troca de página
  }, 700); // Espera 0.5s para trocar
}

// =======================
// FADE IN NA ENTRADA DA PÁGINA
// =======================
window.onload = () => {
  document.body.classList.remove("hidden");
};